# Add this code after line 110 (after CORS middleware) in main.py
# This enables serving the React frontend from /static

from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

# Mount static files (React frontend build)
STATIC_DIR = Path(__file__).parent.parent / "static"
if STATIC_DIR.exists():
    app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")
    
    # Serve index.html for root path and all non-API routes (SPA routing)
    @app.get("/")
    async def serve_root():
        return FileResponse(STATIC_DIR / "index.html")
    
    # Catch-all route for SPA (must be last)
    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        # Don't intercept API routes
        if full_path.startswith("api/") or full_path.startswith("health") or full_path.startswith("jobs"):
            raise HTTPException(status_code=404)
        return FileResponse(STATIC_DIR / "index.html")
    
    logger.info(f"📦 Serving static files from: {STATIC_DIR}")
else:
    logger.warning(f"⚠️  Static directory not found: {STATIC_DIR}")
